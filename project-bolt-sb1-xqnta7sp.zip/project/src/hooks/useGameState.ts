import { useState } from 'react';
import { GameState, Player, EmojiCharacter } from '../types/game';
import { BattleEngine } from '../utils/battle';
import { StorageManager } from '../utils/storage';

export const useGameState = () => {
  const [gameState, setGameState] = useState<GameState>({
    phase: 'menu',
    currentPlayer: 0,
    players: [
      { id: 'player1', name: 'Player 1', wins: 0, losses: 0 },
      { id: 'player2', name: 'Player 2', wins: 0, losses: 0 }
    ],
    battleLog: []
  });

  const startGame = () => {
    setGameState(prev => ({
      ...prev,
      phase: 'selection',
      currentPlayer: 0,
      players: prev.players.map(p => ({ ...p, character: undefined }))
    }));
  };

  const selectCharacter = (character: EmojiCharacter, playerIndex: number) => {
    setGameState(prev => {
      const newPlayers = [...prev.players];
      newPlayers[playerIndex] = {
        ...newPlayers[playerIndex],
        character: { ...character }
      };

      // If both players have selected characters, start battle
      const allSelected = newPlayers.every(p => p.character);
      
      return {
        ...prev,
        players: newPlayers,
        currentPlayer: allSelected ? 0 : 1,
        phase: allSelected ? 'battle' : 'selection'
      };
    });
  };

  const endBattle = (winner: Player) => {
    // Update statistics
    StorageManager.updatePlayerStats(winner.id, true);
    const loser = gameState.players.find(p => p.id !== winner.id);
    if (loser) {
      StorageManager.updatePlayerStats(loser.id, false);
    }

    setGameState(prev => ({
      ...prev,
      phase: 'results',
      winner
    }));
  };

  const returnToMenu = () => {
    setGameState(prev => ({
      ...prev,
      phase: 'menu',
      currentPlayer: 0,
      winner: undefined,
      battleLog: [],
      players: prev.players.map(p => {
        if (p.character) {
          BattleEngine.resetCharacter(p.character);
        }
        return { ...p, character: undefined };
      })
    }));
  };

  const showLeaderboard = () => {
    setGameState(prev => ({
      ...prev,
      phase: 'leaderboard'
    }));
  };

  const playAgain = () => {
    setGameState(prev => ({
      ...prev,
      phase: 'selection',
      currentPlayer: 0,
      winner: undefined,
      battleLog: [],
      players: prev.players.map(p => {
        if (p.character) {
          BattleEngine.resetCharacter(p.character);
        }
        return { ...p, character: undefined };
      })
    }));
  };

  return {
    gameState,
    startGame,
    selectCharacter,
    endBattle,
    returnToMenu,
    showLeaderboard,
    playAgain
  };
};