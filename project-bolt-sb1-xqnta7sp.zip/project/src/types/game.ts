export interface EmojiCharacter {
  id: string;
  emoji: string;
  name: string;
  health: number;
  maxHealth: number;
  attack: number;
  defense: number;
  energy: number;
  maxEnergy: number;
  speed: number;
  special: {
    name: string;
    description: string;
    energyCost: number;
    damage: number;
  };
}

export interface Player {
  id: string;
  name: string;
  character?: EmojiCharacter;
  wins: number;
  losses: number;
}

export interface BattleAction {
  type: 'attack' | 'defend' | 'special';
  damage?: number;
  energyGain?: number;
  critical?: boolean;
  dodged?: boolean;
}

export interface GameState {
  phase: 'menu' | 'selection' | 'battle' | 'results' | 'leaderboard';
  currentPlayer: number;
  players: Player[];
  battleLog: string[];
  winner?: Player;
}