import { EmojiCharacter, BattleAction } from '../types/game';

export class BattleEngine {
  static calculateDamage(attacker: EmojiCharacter, defender: EmojiCharacter, action: BattleAction): number {
    let baseDamage = 0;
    
    switch (action.type) {
      case 'attack':
        baseDamage = attacker.attack;
        break;
      case 'special':
        baseDamage = attacker.special.damage;
        break;
      default:
        return 0;
    }
    
    // Apply defense reduction
    const defense = action.type === 'special' ? defender.defense * 0.5 : defender.defense;
    let finalDamage = Math.max(1, baseDamage - defense);
    
    // Random variance (±20%)
    const variance = 0.8 + Math.random() * 0.4;
    finalDamage *= variance;
    
    // Critical hit chance (15%)
    if (Math.random() < 0.15) {
      finalDamage *= 1.8;
      action.critical = true;
    }
    
    // Dodge chance based on speed (max 25%)
    const dodgeChance = Math.min(0.25, defender.speed / 100);
    if (Math.random() < dodgeChance) {
      action.dodged = true;
      return 0;
    }
    
    return Math.round(finalDamage);
  }

  static gainEnergy(character: EmojiCharacter, amount: number = 20): void {
    character.energy = Math.min(character.maxEnergy, character.energy + amount);
  }

  static canUseSpecial(character: EmojiCharacter): boolean {
    return character.energy >= character.special.energyCost;
  }

  static useSpecial(character: EmojiCharacter): void {
    character.energy -= character.special.energyCost;
  }

  static defend(character: EmojiCharacter): void {
    // Defending grants extra energy and temporary defense boost
    this.gainEnergy(character, 30);
  }

  static applyDamage(character: EmojiCharacter, damage: number): void {
    character.health = Math.max(0, character.health - damage);
  }

  static isDefeated(character: EmojiCharacter): boolean {
    return character.health <= 0;
  }

  static resetCharacter(character: EmojiCharacter): void {
    character.health = character.maxHealth;
    character.energy = 0;
  }
}