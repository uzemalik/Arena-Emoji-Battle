import { Player } from '../types/game';

const STORAGE_KEY = 'emoji-battle-arena';

export interface GameData {
  players: Player[];
  totalBattles: number;
}

export class StorageManager {
  static saveData(data: GameData): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save game data:', error);
    }
  }

  static loadData(): GameData {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error('Failed to load game data:', error);
    }
    
    return {
      players: [],
      totalBattles: 0
    };
  }

  static updatePlayerStats(playerId: string, won: boolean): void {
    const data = this.loadData();
    let player = data.players.find(p => p.id === playerId);
    
    if (!player) {
      player = {
        id: playerId,
        name: playerId,
        wins: 0,
        losses: 0
      };
      data.players.push(player);
    }
    
    if (won) {
      player.wins++;
    } else {
      player.losses++;
    }
    
    data.totalBattles++;
    this.saveData(data);
  }

  static getLeaderboard(): Player[] {
    const data = this.loadData();
    return data.players
      .sort((a, b) => {
        const aWinRate = a.wins / (a.wins + a.losses) || 0;
        const bWinRate = b.wins / (b.wins + b.losses) || 0;
        return bWinRate - aWinRate || b.wins - a.wins;
      })
      .slice(0, 10);
  }

  static clearData(): void {
    localStorage.removeItem(STORAGE_KEY);
  }
}