class AudioManager {
  private context: AudioContext;
  private isEnabled: boolean = true;

  constructor() {
    this.context = new (window.AudioContext || (window as any).webkitAudioContext)();
  }

  private async createSound(frequency: number, type: OscillatorType = 'sine', duration: number = 0.2) {
    if (!this.isEnabled) return;

    try {
      const oscillator = this.context.createOscillator();
      const gainNode = this.context.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(this.context.destination);
      
      oscillator.frequency.setValueAtTime(frequency, this.context.currentTime);
      oscillator.type = type;
      
      gainNode.gain.setValueAtTime(0.3, this.context.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, this.context.currentTime + duration);
      
      oscillator.start(this.context.currentTime);
      oscillator.stop(this.context.currentTime + duration);
    } catch (error) {
      console.warn('Audio playback failed:', error);
    }
  }

  async playAttack() {
    await this.createSound(220, 'square', 0.15);
  }

  async playDefend() {
    await this.createSound(330, 'triangle', 0.2);
  }

  async playSpecial() {
    await this.createSound(440, 'sawtooth', 0.3);
    setTimeout(() => this.createSound(550, 'sawtooth', 0.2), 100);
  }

  async playDamage() {
    await this.createSound(150, 'square', 0.1);
  }

  async playCritical() {
    await this.createSound(660, 'square', 0.25);
  }

  async playSelect() {
    await this.createSound(523, 'sine', 0.1);
  }

  async playVictory() {
    const notes = [523, 659, 784, 1047];
    for (let i = 0; i < notes.length; i++) {
      setTimeout(() => this.createSound(notes[i], 'sine', 0.3), i * 200);
    }
  }

  async playDefeat() {
    const notes = [392, 330, 262, 196];
    for (let i = 0; i < notes.length; i++) {
      setTimeout(() => this.createSound(notes[i], 'triangle', 0.4), i * 150);
    }
  }

  toggle() {
    this.isEnabled = !this.isEnabled;
    return this.isEnabled;
  }

  get enabled() {
    return this.isEnabled;
  }
}

export const audioManager = new AudioManager();