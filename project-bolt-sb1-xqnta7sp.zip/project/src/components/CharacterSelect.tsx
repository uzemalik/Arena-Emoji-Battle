import React from 'react';
import { EmojiCharacter } from '../types/game';
import { EMOJI_CHARACTERS } from '../data/characters';
import { audioManager } from '../utils/audio';

interface CharacterSelectProps {
  onSelect: (character: EmojiCharacter, playerIndex: number) => void;
  selectedCharacters: (EmojiCharacter | null)[];
  currentPlayer: number;
}

export const CharacterSelect: React.FC<CharacterSelectProps> = ({
  onSelect,
  selectedCharacters,
  currentPlayer
}) => {
  const handleSelect = (character: EmojiCharacter) => {
    // Check if character is already selected
    if (selectedCharacters.some(c => c?.id === character.id)) {
      return;
    }
    
    audioManager.playSelect();
    onSelect({ ...character }, currentPlayer);
  };

  const isSelected = (characterId: string) => {
    return selectedCharacters.some(c => c?.id === characterId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-white mb-4 tracking-wider">
            ⚡ EMOJI BATTLE ARENA ⚡
          </h1>
          <div className="text-2xl text-cyan-300 mb-6">
            Player {currentPlayer + 1}: Choose Your Fighter!
          </div>
          
          {selectedCharacters[0] && (
            <div className="mb-6">
              <div className="inline-flex items-center gap-4 bg-black/30 rounded-lg p-4">
                <span className="text-sm text-gray-300">Player 1:</span>
                <span className="text-4xl">{selectedCharacters[0].emoji}</span>
                <span className="text-white font-semibold">{selectedCharacters[0].name}</span>
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {EMOJI_CHARACTERS.map((character) => {
            const selected = isSelected(character.id);
            
            return (
              <div
                key={character.id}
                onClick={() => !selected && handleSelect(character)}
                className={`
                  relative bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl p-6 
                  border-2 cursor-pointer transition-all duration-300 transform
                  ${selected 
                    ? 'border-red-500 opacity-50 scale-95 cursor-not-allowed' 
                    : 'border-cyan-500 hover:border-yellow-400 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/20'
                  }
                `}
              >
                {selected && (
                  <div className="absolute inset-0 bg-red-500/20 rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold bg-red-600 px-3 py-1 rounded-full text-sm">
                      TAKEN
                    </span>
                  </div>
                )}
                
                <div className="text-center">
                  <div className="text-6xl mb-4">{character.emoji}</div>
                  <h3 className="text-xl font-bold text-white mb-3">{character.name}</h3>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-red-400">❤️ Health:</span>
                      <span className="text-white font-semibold">{character.maxHealth}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-orange-400">⚔️ Attack:</span>
                      <span className="text-white font-semibold">{character.attack}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-400">🛡️ Defense:</span>
                      <span className="text-white font-semibold">{character.defense}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-400">⚡ Speed:</span>
                      <span className="text-white font-semibold">{character.speed}</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 p-3 bg-black/30 rounded-lg">
                    <div className="text-yellow-400 font-semibold text-xs mb-1">
                      🌟 {character.special.name}
                    </div>
                    <div className="text-gray-300 text-xs">
                      {character.special.description}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {selectedCharacters[1] && (
          <div className="text-center mt-8">
            <div className="inline-flex items-center gap-4 bg-black/30 rounded-lg p-4">
              <span className="text-sm text-gray-300">Player 2:</span>
              <span className="text-4xl">{selectedCharacters[1].emoji}</span>
              <span className="text-white font-semibold">{selectedCharacters[1].name}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};