import React from 'react';
import { Player } from '../types/game';
import { StorageManager } from '../utils/storage';

interface LeaderboardProps {
  onReturn: () => void;
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ onReturn }) => {
  const leaderboard = StorageManager.getLeaderboard();

  const getWinRate = (player: Player) => {
    const total = player.wins + player.losses;
    return total > 0 ? Math.round((player.wins / total) * 100) : 0;
  };

  const getTrophyEmoji = (rank: number) => {
    switch (rank) {
      case 0: return '🥇';
      case 1: return '🥈';
      case 2: return '🥉';
      default: return '🏅';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold text-white mb-4 tracking-wider">
            🏆 LEADERBOARD 🏆
          </h1>
          <p className="text-xl text-cyan-300">Hall of Champions</p>
        </div>

        <div className="bg-black/30 rounded-xl p-6 mb-8">
          {leaderboard.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🎮</div>
              <h3 className="text-2xl font-bold text-white mb-2">No Battles Yet!</h3>
              <p className="text-gray-300">Start battling to see your stats here.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {leaderboard.map((player, index) => (
                <div
                  key={player.id}
                  className={`
                    flex items-center justify-between p-4 rounded-lg transition-all duration-200
                    ${index === 0 
                      ? 'bg-gradient-to-r from-yellow-600/30 to-yellow-500/30 border-2 border-yellow-400' 
                      : index === 1
                      ? 'bg-gradient-to-r from-gray-600/30 to-gray-500/30 border-2 border-gray-400'
                      : index === 2
                      ? 'bg-gradient-to-r from-orange-600/30 to-orange-500/30 border-2 border-orange-400'
                      : 'bg-gray-800/50 border border-gray-600'
                    }
                  `}
                >
                  <div className="flex items-center gap-4">
                    <div className="text-3xl">
                      {getTrophyEmoji(index)}
                    </div>
                    <div>
                      <div className="text-lg font-bold text-white">
                        #{index + 1} {player.name}
                      </div>
                      <div className="text-sm text-gray-300">
                        {player.wins + player.losses} battles fought
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-white">
                      {getWinRate(player)}%
                    </div>
                    <div className="text-sm text-gray-300">
                      {player.wins}W / {player.losses}L
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Statistics */}
        {leaderboard.length > 0 && (
          <div className="bg-black/30 rounded-xl p-6 mb-8">
            <h3 className="text-xl font-bold text-white mb-4">📊 Battle Statistics</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-cyan-400">
                  {StorageManager.loadData().totalBattles}
                </div>
                <div className="text-sm text-gray-300">Total Battles</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">
                  {leaderboard.length}
                </div>
                <div className="text-sm text-gray-300">Active Players</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-yellow-400">
                  {leaderboard[0]?.wins || 0}
                </div>
                <div className="text-sm text-gray-300">Most Wins</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">
                  {Math.max(...leaderboard.map(p => getWinRate(p)), 0)}%
                </div>
                <div className="text-sm text-gray-300">Best Win Rate</div>
              </div>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-center gap-4">
          <button
            onClick={onReturn}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
          >
            🎮 Back to Game
          </button>
          
          <button
            onClick={() => {
              if (confirm('Are you sure you want to clear all leaderboard data?')) {
                StorageManager.clearData();
                window.location.reload();
              }
            }}
            className="bg-red-600 hover:bg-red-500 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
          >
            🗑️ Clear Data
          </button>
        </div>
      </div>
    </div>
  );
};