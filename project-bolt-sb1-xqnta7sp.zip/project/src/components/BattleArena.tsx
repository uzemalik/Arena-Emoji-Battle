import React, { useState, useEffect } from 'react';
import { EmojiCharacter, BattleAction, Player } from '../types/game';
import { BattleEngine } from '../utils/battle';
import { audioManager } from '../utils/audio';

interface BattleArenaProps {
  players: Player[];
  onBattleEnd: (winner: Player) => void;
  onReturnToMenu: () => void;
}

export const BattleArena: React.FC<BattleArenaProps> = ({
  players,
  onBattleEnd,
  onReturnToMenu
}) => {
  const [currentTurn, setCurrentTurn] = useState(0);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [isAnimating, setIsAnimating] = useState(false);
  const [damageNumbers, setDamageNumbers] = useState<Array<{id: number, damage: number, x: number, y: number, critical?: boolean}>>([]);
  const [shakeScreen, setShakeScreen] = useState(false);

  const currentPlayer = players[currentTurn];
  const opponent = players[currentTurn === 0 ? 1 : 0];

  useEffect(() => {
    // Initial battle message
    setBattleLog([`Battle begins! ${players[0].character?.name} vs ${players[1].character?.name}`]);
  }, [players]);

  const addToLog = (message: string) => {
    setBattleLog(prev => [...prev.slice(-4), message]);
  };

  const showDamageNumber = (damage: number, critical: boolean = false) => {
    const id = Date.now();
    const x = 300 + Math.random() * 200;
    const y = 200 + Math.random() * 100;
    
    setDamageNumbers(prev => [...prev, { id, damage, x, y, critical }]);
    
    setTimeout(() => {
      setDamageNumbers(prev => prev.filter(num => num.id !== id));
    }, 1500);
  };

  const triggerScreenShake = () => {
    setShakeScreen(true);
    setTimeout(() => setShakeScreen(false), 300);
  };

  const executeAction = async (actionType: 'attack' | 'defend' | 'special') => {
    if (isAnimating || !currentPlayer.character || !opponent.character) return;

    setIsAnimating(true);
    const action: BattleAction = { type: actionType };

    try {
      switch (actionType) {
        case 'attack':
          audioManager.playAttack();
          const attackDamage = BattleEngine.calculateDamage(currentPlayer.character, opponent.character, action);
          
          if (action.dodged) {
            addToLog(`${opponent.character.name} dodged the attack!`);
          } else {
            BattleEngine.applyDamage(opponent.character, attackDamage);
            showDamageNumber(attackDamage, action.critical);
            
            if (action.critical) {
              audioManager.playCritical();
              triggerScreenShake();
              addToLog(`💥 Critical hit! ${currentPlayer.character.name} deals ${attackDamage} damage!`);
            } else {
              audioManager.playDamage();
              addToLog(`${currentPlayer.character.name} attacks for ${attackDamage} damage!`);
            }
          }
          
          BattleEngine.gainEnergy(currentPlayer.character, 15);
          break;

        case 'defend':
          audioManager.playDefend();
          BattleEngine.defend(currentPlayer.character);
          addToLog(`${currentPlayer.character.name} defends and gains energy!`);
          break;

        case 'special':
          if (!BattleEngine.canUseSpecial(currentPlayer.character)) {
            addToLog(`Not enough energy for ${currentPlayer.character.special.name}!`);
            setIsAnimating(false);
            return;
          }
          
          audioManager.playSpecial();
          BattleEngine.useSpecial(currentPlayer.character);
          
          const specialDamage = BattleEngine.calculateDamage(currentPlayer.character, opponent.character, action);
          
          if (action.dodged) {
            addToLog(`${opponent.character.name} dodged ${currentPlayer.character.special.name}!`);
          } else {
            BattleEngine.applyDamage(opponent.character, specialDamage);
            showDamageNumber(specialDamage, true);
            triggerScreenShake();
            
            if (action.critical) {
              audioManager.playCritical();
              addToLog(`🌟 MEGA CRITICAL! ${currentPlayer.character.special.name} deals ${specialDamage} damage!`);
            } else {
              audioManager.playDamage();
              addToLog(`${currentPlayer.character.name} uses ${currentPlayer.character.special.name} for ${specialDamage} damage!`);
            }
          }
          break;
      }

      // Check for battle end
      if (BattleEngine.isDefeated(opponent.character)) {
        setTimeout(() => {
          audioManager.playVictory();
          onBattleEnd(currentPlayer);
        }, 1000);
        addToLog(`${opponent.character.name} is defeated! ${currentPlayer.character.name} wins!`);
      } else {
        // Switch turns
        setTimeout(() => {
          setCurrentTurn(prev => prev === 0 ? 1 : 0);
          setIsAnimating(false);
        }, 1000);
      }
    } catch (error) {
      console.error('Battle action failed:', error);
      setIsAnimating(false);
    }
  };

  const getHealthPercentage = (character: EmojiCharacter) => {
    return (character.health / character.maxHealth) * 100;
  };

  const getEnergyPercentage = (character: EmojiCharacter) => {
    return (character.energy / character.maxEnergy) * 100;
  };

  if (!players[0].character || !players[1].character) {
    return <div>Loading battle...</div>;
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-red-900 via-purple-900 to-blue-900 p-4 ${shakeScreen ? 'animate-pulse' : ''}`}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-white mb-2">⚔️ BATTLE ARENA ⚔️</h1>
          <div className="text-xl text-yellow-300">
            {currentPlayer.character.name}'s Turn
          </div>
        </div>

        {/* Battle Field */}
        <div className="relative bg-black/20 rounded-xl p-8 mb-6 overflow-hidden">
          {/* Damage Numbers */}
          {damageNumbers.map(num => (
            <div
              key={num.id}
              className={`absolute text-2xl font-bold pointer-events-none animate-bounce z-10 ${
                num.critical ? 'text-yellow-400' : 'text-red-400'
              }`}
              style={{
                left: num.x,
                top: num.y,
                animation: 'float-up 1.5s ease-out forwards'
              }}
            >
              -{num.damage}
              {num.critical && '💥'}
            </div>
          ))}

          <div className="grid grid-cols-2 gap-12">
            {/* Player 1 */}
            <div className="text-center">
              <div className="text-8xl mb-4 transform transition-transform duration-300 hover:scale-110">
                {players[0].character.emoji}
              </div>
              <div className="text-xl font-bold text-white mb-2">{players[0].character.name}</div>
              <div className="text-sm text-gray-300 mb-4">Player 1</div>
              
              {/* Health Bar */}
              <div className="mb-2">
                <div className="flex justify-between text-sm text-white mb-1">
                  <span>❤️ Health</span>
                  <span>{players[0].character.health}/{players[0].character.maxHealth}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-red-500 to-red-400 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${getHealthPercentage(players[0].character)}%` }}
                  />
                </div>
              </div>
              
              {/* Energy Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-white mb-1">
                  <span>⚡ Energy</span>
                  <span>{players[0].character.energy}/{players[0].character.maxEnergy}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-cyan-400 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${getEnergyPercentage(players[0].character)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Player 2 */}
            <div className="text-center">
              <div className="text-8xl mb-4 transform transition-transform duration-300 hover:scale-110">
                {players[1].character.emoji}
              </div>
              <div className="text-xl font-bold text-white mb-2">{players[1].character.name}</div>
              <div className="text-sm text-gray-300 mb-4">Player 2</div>
              
              {/* Health Bar */}
              <div className="mb-2">
                <div className="flex justify-between text-sm text-white mb-1">
                  <span>❤️ Health</span>
                  <span>{players[1].character.health}/{players[1].character.maxHealth}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-red-500 to-red-400 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${getHealthPercentage(players[1].character)}%` }}
                  />
                </div>
              </div>
              
              {/* Energy Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-white mb-1">
                  <span>⚡ Energy</span>
                  <span>{players[1].character.energy}/{players[1].character.maxEnergy}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-blue-500 to-cyan-400 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${getEnergyPercentage(players[1].character)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-center gap-4 mb-6">
          <button
            onClick={() => executeAction('attack')}
            disabled={isAnimating}
            className="bg-red-600 hover:bg-red-500 disabled:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105 disabled:scale-100"
          >
            ⚔️ Attack
          </button>
          
          <button
            onClick={() => executeAction('defend')}
            disabled={isAnimating}
            className="bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105 disabled:scale-100"
          >
            🛡️ Defend
          </button>
          
          <button
            onClick={() => executeAction('special')}
            disabled={isAnimating || !BattleEngine.canUseSpecial(currentPlayer.character)}
            className="bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105 disabled:scale-100"
          >
            🌟 Special
            {currentPlayer.character && (
              <div className="text-xs">({currentPlayer.character.special.energyCost} energy)</div>
            )}
          </button>
        </div>

        {/* Battle Log */}
        <div className="bg-black/40 rounded-lg p-4 mb-6">
          <h3 className="text-lg font-bold text-white mb-3">📜 Battle Log</h3>
          <div className="space-y-1 max-h-24 overflow-y-auto">
            {battleLog.map((log, index) => (
              <div key={index} className="text-gray-300 text-sm">
                {log}
              </div>
            ))}
          </div>
        </div>

        {/* Exit Button */}
        <div className="text-center">
          <button
            onClick={onReturnToMenu}
            className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-6 rounded-lg transition-all duration-200"
          >
            🏠 Return to Menu
          </button>
        </div>
      </div>

      <style jsx>{`
        @keyframes float-up {
          0% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
          100% {
            opacity: 0;
            transform: translateY(-50px) scale(1.5);
          }
        }
      `}</style>
    </div>
  );
};