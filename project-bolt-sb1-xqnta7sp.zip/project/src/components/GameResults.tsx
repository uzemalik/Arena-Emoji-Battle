import React from 'react';
import { Player } from '../types/game';

interface GameResultsProps {
  winner: Player;
  players: Player[];
  onPlayAgain: () => void;
  onReturnToMenu: () => void;
}

export const GameResults: React.FC<GameResultsProps> = ({
  winner,
  players,
  onPlayAgain,
  onReturnToMenu
}) => {
  const loser = players.find(p => p.id !== winner.id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-900 via-blue-900 to-purple-900 flex items-center justify-center p-6">
      <div className="max-w-2xl w-full bg-black/40 rounded-xl p-8 text-center">
        <div className="text-6xl mb-6">🎉</div>
        
        <h1 className="text-4xl font-bold text-white mb-4">
          VICTORY!
        </h1>
        
        <div className="mb-8">
          <div className="text-6xl mb-4">{winner.character?.emoji}</div>
          <h2 className="text-3xl font-bold text-yellow-400 mb-2">
            {winner.character?.name}
          </h2>
          <p className="text-xl text-white">
            {winner.name} is the champion!
          </p>
        </div>

        {loser && (
          <div className="mb-8 p-4 bg-gray-800/50 rounded-lg">
            <h3 className="text-lg text-gray-300 mb-2">Defeated:</h3>
            <div className="flex items-center justify-center gap-3">
              <span className="text-3xl opacity-50">{loser.character?.emoji}</span>
              <span className="text-white">{loser.character?.name}</span>
            </div>
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={onPlayAgain}
            className="bg-green-600 hover:bg-green-500 text-white font-bold py-3 px-8 rounded-lg transition-all duration-200 transform hover:scale-105"
          >
            🔄 Play Again
          </button>
          
          <button
            onClick={onReturnToMenu}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded-lg transition-all duration-200 transform hover:scale-105"
          >
            🏠 Main Menu
          </button>
        </div>
      </div>
    </div>
  );
};