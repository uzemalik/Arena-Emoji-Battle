import React from 'react';
import { audioManager } from '../utils/audio';

interface MainMenuProps {
  onStartGame: () => void;
  onShowLeaderboard: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  onStartGame,
  onShowLeaderboard
}) => {
  const handleStartGame = () => {
    audioManager.playSelect();
    onStartGame();
  };

  const handleShowLeaderboard = () => {
    audioManager.playSelect();
    onShowLeaderboard();
  };

  const toggleSound = () => {
    const enabled = audioManager.toggle();
    audioManager.playSelect();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-6">
      <div className="text-center max-w-2xl w-full">
        {/* Title */}
        <div className="mb-12">
          <h1 className="text-6xl font-bold text-white mb-4 tracking-wider animate-pulse">
            ⚡ EMOJI BATTLE ARENA ⚡
          </h1>
          <p className="text-xl text-cyan-300 mb-6">
            Choose your emoji warrior and dominate the arena!
          </p>
          <div className="flex justify-center gap-4 text-4xl mb-8">
            <span className="animate-bounce">🐉</span>
            <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>🥷</span>
            <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>🤖</span>
            <span className="animate-bounce" style={{ animationDelay: '0.6s' }}>🧙‍♂️</span>
          </div>
        </div>

        {/* Menu Buttons */}
        <div className="space-y-4 mb-8">
          <button
            onClick={handleStartGame}
            className="w-full sm:w-auto bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-bold py-4 px-8 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            🎮 Start Battle
          </button>
          
          <br />
          
          <button
            onClick={handleShowLeaderboard}
            className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold py-4 px-8 rounded-xl transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            🏆 Leaderboard
          </button>
        </div>

        {/* Settings */}
        <div className="flex justify-center gap-4">
          <button
            onClick={toggleSound}
            className={`
              px-4 py-2 rounded-lg font-semibold transition-all duration-200
              ${audioManager.enabled 
                ? 'bg-green-600 hover:bg-green-500 text-white' 
                : 'bg-gray-600 hover:bg-gray-500 text-gray-300'
              }
            `}
          >
            {audioManager.enabled ? '🔊' : '🔇'} Sound
          </button>
        </div>

        {/* Game Info */}
        <div className="mt-12 text-gray-400 text-sm">
          <p>Turn-based tactical combat • Local multiplayer • 8 unique fighters</p>
        </div>
      </div>
    </div>
  );
};