import { EmojiCharacter } from '../types/game';

export const EMOJI_CHARACTERS: EmojiCharacter[] = [
  {
    id: 'dragon',
    emoji: '🐉',
    name: 'Fire Dragon',
    health: 120,
    maxHealth: 120,
    attack: 25,
    defense: 15,
    energy: 0,
    maxEnergy: 100,
    speed: 18,
    special: {
      name: 'Dragon Breath',
      description: 'Devastating fire attack',
      energyCost: 40,
      damage: 45
    }
  },
  {
    id: 'ninja',
    emoji: '🥷',
    name: 'Shadow Ninja',
    health: 100,
    maxHealth: 100,
    attack: 30,
    defense: 10,
    energy: 0,
    maxEnergy: 100,
    speed: 25,
    special: {
      name: 'Shadow Strike',
      description: 'Swift critical attack',
      energyCost: 35,
      damage: 50
    }
  },
  {
    id: 'robot',
    emoji: '🤖',
    name: 'Cyber Bot',
    health: 110,
    maxHealth: 110,
    attack: 22,
    defense: 20,
    energy: 0,
    maxEnergy: 100,
    speed: 15,
    special: {
      name: 'Power Surge',
      description: 'Electric overload',
      energyCost: 45,
      damage: 40
    }
  },
  {
    id: 'wizard',
    emoji: '🧙‍♂️',
    name: 'Arcane Wizard',
    health: 90,
    maxHealth: 90,
    attack: 28,
    defense: 12,
    energy: 0,
    maxEnergy: 100,
    speed: 20,
    special: {
      name: 'Magic Missile',
      description: 'Mystical energy blast',
      energyCost: 30,
      damage: 48
    }
  },
  {
    id: 'viking',
    emoji: '⚔️',
    name: 'Norse Warrior',
    health: 130,
    maxHealth: 130,
    attack: 26,
    defense: 18,
    energy: 0,
    maxEnergy: 100,
    speed: 12,
    special: {
      name: 'Berserker Rage',
      description: 'Furious combo attack',
      energyCost: 50,
      damage: 38
    }
  },
  {
    id: 'alien',
    emoji: '👽',
    name: 'Space Invader',
    health: 95,
    maxHealth: 95,
    attack: 32,
    defense: 8,
    energy: 0,
    maxEnergy: 100,
    speed: 22,
    special: {
      name: 'Plasma Beam',
      description: 'Alien technology',
      energyCost: 38,
      damage: 52
    }
  },
  {
    id: 'pirate',
    emoji: '🏴‍☠️',
    name: 'Sea Captain',
    health: 105,
    maxHealth: 105,
    attack: 24,
    defense: 16,
    energy: 0,
    maxEnergy: 100,
    speed: 16,
    special: {
      name: 'Cannon Blast',
      description: 'Explosive cannonball',
      energyCost: 42,
      damage: 44
    }
  },
  {
    id: 'phoenix',
    emoji: '🔥',
    name: 'Phoenix Flame',
    health: 85,
    maxHealth: 85,
    attack: 35,
    defense: 5,
    energy: 0,
    maxEnergy: 100,
    speed: 28,
    special: {
      name: 'Rebirth Flame',
      description: 'Healing fire',
      energyCost: 60,
      damage: 35
    }
  }
];